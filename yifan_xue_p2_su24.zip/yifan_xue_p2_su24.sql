CREATE TABLE `Customer` (
  `CustomerID` INT PRIMARY KEY,
  `Name` VARCHAR,
  `Address` VARCHAR,
  `Phone` VARCHAR,
  `Email` VARCHAR
);

CREATE TABLE `Account` (
  `AccountID` INT PRIMARY KEY,
  `CustomerID` INT,
  `AccountType` VARCHAR,
  `Status` VARCHAR,
  `CreatedDate` timestamp
);

CREATE TABLE `BillingAccount` (
  `BillingAccountID` INT PRIMARY KEY,
  `AccountID` INT,
  `Address` VARCHAR,
  `City` VARCHAR,
  `State` VARCHAR,
  `ZIP` VARCHAR,
  `BillingType` VARCHAR
);

CREATE TABLE `AccountAdmin` (
  `AccountAdminID` INT PRIMARY KEY,
  `AccountID` INT,
  `AdminName` VARCHAR,
  `Role` VARCHAR,
  `AssignedDate` DATE
);

CREATE TABLE `Policy` (
  `PolicyID` INT PRIMARY KEY,
  `AccountID` INT,
  `PolicyType` VARCHAR,
  `EffectiveDate` DATE,
  `ExpirationDate` DATE,
  `Premium` DECIMAL
);

CREATE TABLE `PolicyBenefit` (
  `BenefitID` INT PRIMARY KEY,
  `PolicyID` INT,
  `BenefitType` VARCHAR,
  `CoverageAmount` DECIMAL
);

CREATE TABLE `Claim` (
  `ClaimID` INT PRIMARY KEY,
  `PolicyID` INT,
  `ClaimDate` DATE,
  `Amount` DECIMAL,
  `Status` VARCHAR
);

CREATE TABLE `Associate` (
  `AssociateID` INT PRIMARY KEY,
  `Name` VARCHAR,
  `ContactInfo` VARCHAR,
  `Role` VARCHAR
);

CREATE TABLE `ManagerContract` (
  `ManagerContractID` INT PRIMARY KEY,
  `AssociateID` INT,
  `PolicyID` INT,
  `ContractType` VARCHAR,
  `StartDate` DATE,
  `EndDate` DATE
);

CREATE TABLE `CustomerContract` (
  `CustomerContractID` INT PRIMARY KEY,
  `CustomerID` INT,
  `PolicyID` INT,
  `ContractRole` VARCHAR(50) COMMENT 'Owner,Beneficiary,Payer',
  `StartDate` DATE,
  `EndDate` DATE
);

CREATE TABLE `AccountAlias` (
  `AliasID` INT PRIMARY KEY,
  `AccountID` INT,
  `OriginalEntry` VARCHAR(255),
  `SourceSystem` VARCHAR(100),
  `CreatedDate` DATE
);

CREATE TABLE `CustomerReview` (
  `customer_id` INT PRIMARY KEY,
  `drug_name` NVARCHAR,
  `age` NVARCHAR,
  `gender` NVARCHAR,
  `time_on_drug` NVARCHAR,
  `reviewer_type` NVARCHAR,
  `condition` NVARCHAR,
  `rating_overall` FLOAT,
  `rating_effectiveness` INT,
  `rating_ease_of_use` INT,
  `rating_satisfaction` INT
);

ALTER TABLE `Account` ADD FOREIGN KEY (`CustomerID`) REFERENCES `Customer` (`CustomerID`);

ALTER TABLE `BillingAccount` ADD FOREIGN KEY (`AccountID`) REFERENCES `Account` (`AccountID`);

ALTER TABLE `AccountAdmin` ADD FOREIGN KEY (`AccountID`) REFERENCES `Account` (`AccountID`);

ALTER TABLE `Policy` ADD FOREIGN KEY (`AccountID`) REFERENCES `Account` (`AccountID`);

ALTER TABLE `PolicyBenefit` ADD FOREIGN KEY (`PolicyID`) REFERENCES `Policy` (`PolicyID`);

ALTER TABLE `Claim` ADD FOREIGN KEY (`PolicyID`) REFERENCES `Policy` (`PolicyID`);

ALTER TABLE `ManagerContract` ADD FOREIGN KEY (`AssociateID`) REFERENCES `Associate` (`AssociateID`);

ALTER TABLE `ManagerContract` ADD FOREIGN KEY (`PolicyID`) REFERENCES `Policy` (`PolicyID`);

CREATE TABLE `Customer_CustomerContract` (
  `Customer_CustomerID` INT,
  `CustomerContract_CustomerID` INT,
  PRIMARY KEY (`Customer_CustomerID`, `CustomerContract_CustomerID`)
);

ALTER TABLE `Customer_CustomerContract` ADD FOREIGN KEY (`Customer_CustomerID`) REFERENCES `Customer` (`CustomerID`);

ALTER TABLE `Customer_CustomerContract` ADD FOREIGN KEY (`CustomerContract_CustomerID`) REFERENCES `CustomerContract` (`CustomerID`);


CREATE TABLE `Policy_CustomerContract` (
  `Policy_PolicyID` INT,
  `CustomerContract_PolicyID` INT,
  PRIMARY KEY (`Policy_PolicyID`, `CustomerContract_PolicyID`)
);

ALTER TABLE `Policy_CustomerContract` ADD FOREIGN KEY (`Policy_PolicyID`) REFERENCES `Policy` (`PolicyID`);

ALTER TABLE `Policy_CustomerContract` ADD FOREIGN KEY (`CustomerContract_PolicyID`) REFERENCES `CustomerContract` (`PolicyID`);


ALTER TABLE `AccountAlias` ADD FOREIGN KEY (`AccountID`) REFERENCES `Account` (`AccountID`);

ALTER TABLE `CustomerReview` ADD FOREIGN KEY (`customer_id`) REFERENCES `Customer` (`CustomerID`);
